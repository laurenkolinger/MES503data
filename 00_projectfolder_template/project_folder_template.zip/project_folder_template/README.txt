< THIS VERSION OF README TEMPLATE IS JUST FOR MES 504 WEEK 1 ACTIVITY.> 
< THIS IS AN ABBREVIATED VERSION FOR YOUR INITIAL ASSIGNMENT. USE THE COMPLETE README TEMPLATE IN THE TEMPLATES FOLDER FOR ALL OTHER PROJECTS >

< delete help text in angle brackets before finalizing/sumitting this document>
< more explanation of these fields: https://data.research.cornell.edu/data-management/sharing/readme/ >

————————————————————————————————————————— 
# <FOLDER NAME>

This readme file was generated on <YYYY-MM-DD> by <NAME> 
And last modified by <NAME> on <YYYY-MM-DD>

Description/ purpose of this folder: <IMPORTANT but CONCISE DESCRIPTION>

<provide at least two contacts, eg you and lab instructor >
FIRST AUTHOR Information <you>
Name: 
Institution: 
Email: 

Author/Alternate Contact Information
Name: 
Institution: 
Email: 

Date of data collection: <provide single date, range, or approximate date; suggested format YYYY-MM-DD, see original publication for this information https://journals.plos.org/plosone/article?id=10.1371/journal.pone.0090081 > 

Geographic location of data collection: <provide latitude, longiute, or city/region, State, Country, see original publication for this information https://journals.plos.org/plosone/article?id=10.1371/journal.pone.0090081>

Information about funding sources that supported the collection of the data: <see funding statement in original publication https://journals.plos.org/plosone/article?id=10.1371/journal.pone.0090081#s1 > 

Origin: This file was copied from Alison Horst GitHub on <DATE>. link to original data: https://github.com/allisonhorst/palmerpenguins data were originally published in <IN TEXT CITATION> 

————————————————————————————————————————
## File List

<list all folders and subfolders contained in the dataset, with a brief description>

- data: <ADD DESCRIPTION HERE>

	- data_raw: <ADD DESCRIPTION HERE>

	- data_wrangling: contains scripts to ... <ADD DESCRIPTION HERE>

- ... 

<COMPLETE THIS TO MATCH THE ENTIRE CONTENTS OF PROJECT FOLDER >

————————————————————————————————————————
## FILE NAMING CONVENTIONS

< scripts should be numbered sequentially for easy flow and tracking of input/outputs - see lab manual for more detail >

< another example, name data files consistently, eg with a prefix that includes a series of component abbreviations separated by underscores. 

Format follows {dataset}_{parameter}_{sites}_{years}_{filetype}.{extension}

Example data file prefix: TCRMP_coralCover_allsites_2004_2018_dat.csv), where: 
{dataset}: dataset originally derived from: TCRMP, CSUN, VINPS, RRS
{parameter}: measured variable (e.g., coral cover, rugosity)
{sites}: sites from dataset for which data exists (e.g., all sites, BUIS...
{years}: years for which parameter data exist (e.g., 2005_2017)
{filetype}: type of file, dat for data, metadata for metadata, analysis for analysis script. 
This example may or may not apply to the type of data you collect, but you should be consistent>

—————————————————————————————————————————
## METHODOLOGICAL INFORMATION 

Description of methods used for collection/generation of data: <summarize data collection methods, and include links or references to publications or other documentation containing experimental design or protocols used in data collection>

Methods for processing the data: <describe how the data were wrangled and summarized >

Instrument- or software-specific information needed to interpret the data: <include full name and version of software, and any necessary packages or libraries needed to run scripts, eg R v.X.X.X , tidyverse, MASS >

————————————————————————————————————————- 
## SHARING/ACCESS INFORMATION

Links to publications that cite or use the data: < LINK TO PUBLICATION > 

Links to other publicly accessible locations of the data: < LINK TO ALISON HORSTS GITHUB PAGE> 

