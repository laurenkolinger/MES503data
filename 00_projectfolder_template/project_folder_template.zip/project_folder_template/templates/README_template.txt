< delete help text in angle brackets before finalizing/sumitting this document>
< more explanation of these fields: https://data.research.cornell.edu/data-management/sharing/readme/ >
< this document will help you when it comes time to finishing/publishing your thesis/capstone - use it to keep yourself and your group organized, and to be able to navigate your way around your project folders. 

—————————————————————————————————————————
# <FOLDER NAME>

This readme file was generated on <YYYY-MM-DD> by <NAME> 
And last modified by <NAME> on <YYYY-MM-DD> 
<periodically check that information here is current, set a once monthly phone/calendar reminder?>

Description/ purpose of this folder: <IMPORTANT but CONCISE DESCRIPTION>

<provide at least two contacts, eg you and your advisor for your masters thesis>
<for capstone, may move this author list down so that dont have to scroll thru everyones names>
FIRST AUTHOR Information <you, if masters thesis>
Name: 
Institution: 
Email: 

Author/Alternate Contact Information
Name: 
Institution: 
Email: 

Date of data collection: <provide single date, range, or approximate date; suggested format YYYY-MM-DD> 

Geographic location of data collection: <provide latitude, longiute, or city/region, State, Country>
 
Information about funding sources that supported the collection of the data: < do you know who is paying for your research? If not, might be a good idea to find out! Put agency / grant numbers here. Will need later if you publish this. One less thing to hunt down > 

Origin: <if copying data over from somewhere else, eg This file was copied by LO from reefResilienceStudy_main in Google Drive folder on 26 June 2023>

—————————————————————————————————————————
## ABBREVIATIONS

<when we get really wrapped up in our projects, sometimes we use abbreviations/jargon that make no sense to anyone else. Here is where you can document that for future reference>
<Eg AC: Aplysina cauliformis (one of the species used in our experiments)>
< Eg TCRMP: Territorial coral reef monitoring program>

—————————————————————————————————————————
## File List

<list all folders and subfolders contained in the dataset, with a brief description>

- data: <ADD DESCRIPTION HERE>

	- data_raw: <ADD DESCRIPTION HERE>

	- …

- <THESE CONTENTS MUST MATCH THE FOLDERS/SUBFOLDERS IN YOUR PROJECT FOLDER EXACTLY AND NEED TO BE KEPT UP TO DATE AS YOU GROW THE PROJECT. ADD FOLDERS BASED ON REQUIREMENTS IN LAB MANUAL, AND ANYTHNG ELSE YOU MAY NEED. EG WILL YOU BE USING AUDIO FILES? WILL YOU BE WORKING IN OTHER PROGRAMMING LANGUAGES OR ANALYSIS ENVIRONMENTS? WILL YOU BE USING EXISTING CODE? WILL YOU BE DOING A LOT OF TRIAL AND ERROR AND PILOT PROJECTS? ARE YOU DOING SAMPLING OR MANIPULATIVE EXPERIMENTS? WILL YOU BE WRITING MANUSCRIPTS FROM YOUR THESIS? DO YOU HAVE A LIT REVIEW AND REFERENCED LIT TO INCLUDE? IF CAPSTONE PROJECT, DO YOU HAVE CLASS NOTES, COLLABORATIVE DOCUMENTS, REQUIRED DELIVERABLES, TIMELINE, ASSIGNMENTS … > 

—————————————————————————————————————————
## FILE NAMING CONVENTIONS

< scripts should be numbered sequentially for easy flow and tracking of input/outputs - see lab manual for more detail >

< another example, name data files consistently, eg with a prefix that includes a series of component abbreviations separated by underscores. 
Format follows {dataset}_{parameter}_{sites}_{years}_{filetype}.{extension}
Example data file prefix: TCRMP_coralCover_allsites_2004_2018_dat.csv), where: 
	{dataset}: dataset originally derived from: TCRMP, CSUN, VINPS, RRS
	{parameter}: measured variable (e.g., coral cover, rugosity)
	{sites}: sites from dataset for which data exists (e.g., all sites, BUIS...
	 {years}: years for which parameter data exist (e.g., 2005_2017)
	{filetype}: type of file, dat for data, metadata for metadata, analysis for analysis script. 
This example may or may not apply to the type of data you collect, but you should be consistent>

—————————————————————————————————————————
## METHODOLOGICAL INFORMATION 

Description of methods used for collection/generation of data: <include links or references to publications or other documentation containing experimental design or protocols used in data collection>

Methods for processing the data: <describe how the submitted data were generated from the raw or collected data>

Instrument- or software-specific information needed to interpret the data: <include full name and version of software, and any necessary packages or libraries needed to run scripts, eg R v.X.X.X , tidyverse, MASS. If using CTD, put the model number here. If using other instrumentation, put that information here. >

Standards and calibration information, if appropriate: < did you have to calibrate a PAM fluorometer, or any kind of analytical instrument? Did you measure total alkalinity and use CRMs to calibrate against? Did you use stable isotopes and use USGS standards for calibrating the Environmental analyzer machine? What ppm precision did these get you?>

Environmental/experimental conditions: < what sort of treatments did you deploy (briefly) and what sorts of controls did you use?> 

Describe any quality-assurance procedures performed on the data: < did you measure with multiple observers to maintain low observer bias? Did you have data entry folks double checkign their inputs? Did you look for outliers or spurious extrema? Did you apply any quality filter, or use any signal to noise thresholds?> 

People involved with sample collection, processing, analysis and/or submission: <anyone not in the author list above who helped with the work. These people may become authors on publications, or they may be named in the acknowledgments. This is a good place to store those names- trust me, it can be hard to remember when you are working on submitting a manuscript, and it feels terrible to forget someone!!>

—————————————————————————————————————————
## SHARING/ACCESS INFORMATION

Licenses/restrictions placed on the data: <read more here https://www.dcc.ac.uk/guidance/how-guides/license-research-data>

Links to publications that cite or use the data: <once you've published your data, here you can add your citation to link the data back to the publication. Or you can cite publications if you are using data previously published>

Links to other publicly accessible locations of the data: <is it on the TCRMP site? Or the Caricoos site?>

Links/relationships to ancillary data sets: < did you use a piece of another dataset? Did your project result in secondary project, or were your pilot data publishable? Did you develop a methodology that became used in other peoples research? Or is your methodology a continuation of other peoples research? >

Recommended citation for this dataset: <ideally you will get a unique DOI for your dataset one day, so others can find it, and attribute it back to your group. This is where that will go> 
